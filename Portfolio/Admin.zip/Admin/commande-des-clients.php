<?php require_once('../Connections/connexion.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "../Connexion.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "admin";
$MM_donotCheckaccess = "false";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && false) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "../Connexion.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_connexion, $connexion);
$query_rsCommandeClient = "SELECT ficheclient.IDclient, ficheclient.Nom, ficheclient.Prenom, commandeclient.Reference, commandeclient.Nompiece, commandeclient.Quantite, commandeclient.DateDeReservation, commandeclient.Facture FROM commandeclient, ficheclient WHERE ficheclient.IDclient = commandeclient.IDclient";
$rsCommandeClient = mysql_query($query_rsCommandeClient, $connexion) or die(mysql_error());
$row_rsCommandeClient = mysql_fetch_assoc($rsCommandeClient);
$totalRows_rsCommandeClient = mysql_num_rows($rsCommandeClient);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Buc motor</title>
<link rel="shortcut icon" href="favicon.ico" />
<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'>
<link href="css/styles.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header-wrap">
	<div class="header">
		<div class="logo"><h1>BUC motor</h1>
		</div>
		<div class="menu">
            	<ul>
       		  <li><a href="index.php" >Acceuil</a></li>
         
          
                <li class="dropbtn dropdown"><a href="#" >Gestion Administrateur</a>

                <ul class="dropdown-content">
               <a  href="Comptabilite-BUC/depensebuc.php"> Section Comptabilité</a>

                 <a href="articles-de-ventes.php">Gestion de stock</a>
                 <a href="page-utilisateur.php"> Mes Utilisateurs</a>

                 <a href="nouvel-utilisateur.php"> Inscrire un User</a>
                </ul>
                </li>
                                <li><a href="commande des clients.php" class="active">Commandes</a></li>
              <li><a href="<?php echo $logoutAction ?>">Déconnexion</a></li>
        	</ul>
        </div>
	</div>
</div><!---header-wrap--->

<div class="wrap">
  <div class="leftcol">
    <div class="search">
      <div class="title">
        <h1>Site Search</h1>
        <div class="search-input">
          <input name="" type="text" class="input-style"/>
        </div>
        <div class="search-btn"><img src="images/search-btn.jpg" alt="search" /></div>
      </div>
    </div>
    <div class="block">
      <div class="panel">
        <div class="title">
          <h1 align="center">AUTRE MENU</h1>
              </div>
              <div class="content">

                	   <ul >
                <li>
                	      <div align="center" class="autremenu"><a href="Comptabilite-BUC/depensebuc.php"> Section Comptabilité</a></div>
                	    </li>
                       <li>
               	         <div align="center" class="autremenu"><a href="page-utilisateur.php"> Mes Utilisateurs</a></div>
           	      </li>
           	      <li>
                	      <div align="center" class="autremenu"><a href="about.php"> A propos de nous</a></div>
                	    </li>
                	    <li>
                	      <div align="center" class="autremenu"><a href="contact.php"> Contactez-nous </a></div>
                	    </li> 
                	    <li>
                	      <div align="center" class="autremenu"><a href="nouvel-utilisateur.php"> Inscrire un User</a></div>
                	    </li>
                	    
              	    </ul>
        </div>
      </div>
    </div>
    <div class="block2">
     <?php include_once('../Personnels/personnel.php'); ?>
      </div>
    </div>
  </div>
  <!---leftcol--->
  <div class="rightcol">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <h1 align="center" class="cssbutton">LISTE DE COMMANDE DES CLIENTS</h1>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <div class="page">
      <div class="panel mar-bottom">
        <?php if ($totalRows_rsCommandeClient > 0) { // Show if recordset not empty ?>
  <table width="">
    <tr>
      <td width=""><h2 align="center">Nr client</h2></td>
      <td width=""><h2 align="center">Prenom</h2></td>
      <td width=""><h2 align="center">Date </h2></td>
      <td width=""><h2 align="center">Facture</h2></td>
    </tr>
    <?php do { ?>
      <tr>
        <td><h3 align="center"><?php echo $row_rsCommandeClient['IDclient']; ?></h3></td>
        <td width="100"><h3 align="center"><?php echo $row_rsCommandeClient['Prenom']; ?></h3></td>
        <td><h3 align="center"><?php echo $row_rsCommandeClient['DateDeReservation']; ?></h3></td>
        <td width="100"><h3 align="center" ><?php echo $row_rsCommandeClient['Facture']; ?></h3></td>
        <td><h3><a href="commande-des-clients-afficher.php?DateDeReservation=<?php echo $row_rsCommandeClient['DateDeReservation']."&IDclient=". $row_rsCommandeClient['IDclient']; ?>;">Voir</a> | <a href="ModifierCommandeClient.php?DateDeReservation=<?php echo $row_rsCommandeClient['DateDeReservation']; ?>">Modifier</a> | <a href="DeleteCommande.php?DateDeReservation=<?php echo $row_rsCommandeClient['DateDeReservation']; ?>" onclick="return confirm('Voulez-vous Vraiment Supprimer Cette Commande ?'); ">Supp</a></h3></td>
        
      </tr>
      <?php } while ($row_rsCommandeClient = mysql_fetch_assoc($rsCommandeClient)); ?>
  </table>
  <?php } // Show if recordset not empty ?>
  <?php if ($totalRows_rsCommandeClient == 0) { // Show if recordset empty ?>
  <h1 align="center"> Il n'y pas de commande encours</h1>
  <?php } // Show if recordset empty ?>
      </div>
    </div>
    <!---page--->
  </div>
  <!---Rightcol--->
</div>
<?php include_once('../footer/footer.php'); ?>
</body>
</html>
<?php
mysql_free_result($rsCommandeClient);
?>
