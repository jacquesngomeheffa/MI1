<?php require_once('../Connections/connexion.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "../index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "admin";
$MM_donotCheckaccess = "false";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && false) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "../index.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO gestionstock (reference, nompiece, Quantite, Prixachat, PrixVente) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['reference'], "text"),
                       GetSQLValueString($_POST['Nompiece'], "text"),
                       GetSQLValueString($_POST['Quantite'], "int"),
                       GetSQLValueString($_POST['prixachat'], "double"),
                       GetSQLValueString($_POST['prixvente'], "double"));

  mysql_select_db($database_connexion, $connexion);
  $Result1 = mysql_query($insertSQL, $connexion) or die(mysql_error());

  $insertGoTo = "article-de-vente.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

$maxRows_rsPieces = 20;
$pageNum_rsPieces = 0;
if (isset($_GET['pageNum_rsPieces'])) {
  $pageNum_rsPieces = $_GET['pageNum_rsPieces'];
}
$startRow_rsPieces = $pageNum_rsPieces * $maxRows_rsPieces;

mysql_select_db($database_connexion, $connexion);
$query_rsPieces = "SELECT * FROM gestionstock";
$query_limit_rsPieces = sprintf("%s LIMIT %d, %d", $query_rsPieces, $startRow_rsPieces, $maxRows_rsPieces);
$rsPieces = mysql_query($query_limit_rsPieces, $connexion) or die(mysql_error());
$row_rsPieces = mysql_fetch_assoc($rsPieces);

if (isset($_GET['totalRows_rsPieces'])) {
  $totalRows_rsPieces = $_GET['totalRows_rsPieces'];
} else {
  $all_rsPieces = mysql_query($query_rsPieces);
  $totalRows_rsPieces = mysql_num_rows($all_rsPieces);
}
$totalPages_rsPieces = ceil($totalRows_rsPieces/$maxRows_rsPieces)-1;

$queryString_rsPieces = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_rsPieces") == false && 
        stristr($param, "totalRows_rsPieces") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_rsPieces = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_rsPieces = sprintf("&totalRows_rsPieces=%d%s", $totalRows_rsPieces, $queryString_rsPieces);
$query_rsPieces = "SELECT * FROM gestionstock";
$rsPieces = mysql_query($query_rsPieces, $connexion) or die(mysql_error());
$row_rsPieces = mysql_fetch_assoc($rsPieces);
$totalRows_rsPieces = mysql_num_rows($rsPieces);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Buc motor</title>
<link rel="shortcut icon" href="favicon.ico" />
<link href="css/cssPourArticleVenteAdmin.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="header-wrap">
	<div class="header">
		<div class="logo"><h1>BUC motor</h1>
		</div>
		<div class="menu">
            	<ul>
       		  <li><a href="index.php" >Acceuil</a></li>
         
          
                <li class="dropbtn dropdown"><a href="#" class="active">Gestion Administrateur</a>

                <ul class="dropdown-content">
               <a  href="Comptabilite-BUC/depensebuc.php"> Section Comptabilité</a>

                 <a href="article-de-vente.php">Gestion de stock</a>
                 <a href="page-utilisateur.php"> Mes Utilisateurs</a>

                 <a href="nouvel-utilisateur.php"> Inscrire un User</a>
                </ul>
                </li>
                                <li><a href="commande-des-clients.php">Commandes</a></li>
              <li><a href="<?php echo $logoutAction ?>">Déconnexion</a></li>
        	</ul>
        </div>
	</div>
</div><!---header-wrap--->

<div class="wrap">
  <div class="leftcol">
		<div class="search">
			<div class="title">
            	<h1>Site Search</h1>
                <div class="search-input"><input name="" type="text" class="input-style"/></div>
                <div class="search-btn"><img src="images/search-btn.jpg" alt="search" /></div>
            </div>
        </div>

		<div class="block">
        	<div class="panel">
            	<div class="title">
           <h1 align="center">AUTRE MENU</h1>
              </div>
              <div class="content">
                	  <ul >
                <li>
                	      <div align="center" class="autremenu"><a href="Comptabilite-BUC/depensebuc.php"> Section Comptabilité</a></div>
                	    </li>
                       <li>
               	         <div align="center" class="autremenu"><a href="page-utilisateur.php"> Mes Utilisateurs</a></div>
           	      </li>
           	      <li>
                	      <div align="center" class="autremenu"><a href="about.php"> A propos de nous</a></div>
                	    </li>
                	    <li>
                	      <div align="center" class="autremenu"><a href="contact.php"> Contactez-nous </a></div>
                	    </li> 
                	    <li>
                	      <div align="center" class="autremenu"><a href="nouvel-utilisateur.php"> Inscrire un User</a></div>
                	    </li>
                	    
              	    </ul>
              </div>
        	</div>
		</div>
        
        <div class="block2">
        	<?php include_once('../Personnels/personnel.php'); ?>
                </div>
    </div>
  </div><!---leftcol--->


<div class="rightcol"><!---page--->
  <h1>&nbsp;</h1>
  <h1 align="center" class="cssbutton">GERER VOS STOCKS </h1>
  <p>&nbsp;</p>
  <?php if ($totalRows_rsPieces > 0) { // Show if recordset not empty ?>
  <table align="center" width="" >
    <tr>
    <td height="40"><h2 align="center">Nr Auto</h2></td>
      <td height="40"><h2 align="center">Référence</h2></td>
      <td height="40"><h2 align="center">Noms pièces</h2></td>
      <td height="40"><h2 align="center">Quantité</h2></td>
      <td height="40"><h2 align="center">Prix d'achat</h2></td>
      <td height="40"><h2 align="center">Prix de vente</h2></td>
    </tr>
    <?php do { ?>
      <tr>
      <td width="100" height="25"><h3 align="center"><?php echo $row_rsPieces['ID_pieces']; ?></h3></td>
        <td width="200" height="25"><h3 align="center"><?php echo $row_rsPieces['reference']; ?></h3>        </td>
        <td width="200" height="25"><h3 align="center"><?php echo $row_rsPieces['nompiece']; ?></h3>        </td>
        <td width="150" height="25"><h3 align="center"><?php echo $row_rsPieces['Quantite']; ?></h3>        </td>
        <td width="200" height="25"><h3 align="center"><?php echo $row_rsPieces['Prixachat']; ?></h3>        </td>
        <td width="200" height="25"><h3 align="center"><?php echo $row_rsPieces['PrixVente']; ?></h3>        </td>
        <td width="200" height="25"><h3 align="center"><a href="modifier-un-stock.php?ID_pieces=<?php echo $row_rsPieces['ID_pieces']; ?>">Modif</a> | <a href="delete-un-stock.php?ID_pieces=<?php echo $row_rsPieces['ID_pieces']; ?>" onclick="return confirm('Voulez-vous Vraiment Le Supprimer ?'); ">Supp</a></h3></td>
      </tr>
      <?php } while ($row_rsPieces = mysql_fetch_assoc($rsPieces)); ?>
  </table>
  <?php } // Show if recordset not empty ?>
   <p align="center">&nbsp;</p>
  <form id="form1" name="form1" method="POST" action="<?php echo $editFormAction; ?>">
     <table width="">
       <tr>
         <td><h2 align="center">Reference</h2></td>
         <td><h2 align="center">Pièce</h2></td>
         <td><h2 align="center">Quantité</h2></td>
         <td><h2 align="center">Prix d'achat</h2></td>
         <td><h2 align="center">Prix de vente</h2></td>
       </tr>
       <tr>
         <td> <div align="center">
           <input type="text" name="reference" id="reference" size="8"/>
         </div></td>
         <td><div align="center">
           <input type="text" name="Nompiece" id="Nompiece" size="20"/>
         </div></td>
         <td><div align="center">
           <input type="text" name="Quantite" id="Quantite" size="10" />
         </div></td>
         <td><div align="center">
           <input type="text" name="prixachat" id="prixachat" size="12" />
         </div></td>
         <td><div align="center">
           <input type="text" name="prixvente" id="prixvente" size="12" />
         </div></td>
         <td><div align="center">
           <input type="submit" name="sauv" id="sauv" value="Ajouter" size="10"/>
         </div></td>
       </tr>
     </table>
     <input type="hidden" name="MM_insert" value="form1" />
   </form>
  <p align="center">&nbsp;</p>
   <p align="center">&nbsp;</p>
   <div align="center">
   <table border="0">
     <tr>
       <td><?php if ($pageNum_rsPieces > 0) { // Show if not first page ?>
           <a href="<?php printf("%s?pageNum_rsPieces=%d%s", $currentPage, 0, $queryString_rsPieces); ?>"><img src="images/First.gif" /></a>
           <?php } // Show if not first page ?></td>
       <td><?php if ($pageNum_rsPieces > 0) { // Show if not first page ?>
           <a href="<?php printf("%s?pageNum_rsPieces=%d%s", $currentPage, max(0, $pageNum_rsPieces - 1), $queryString_rsPieces); ?>"><img src="images/Previous.gif" /></a>
           <?php } // Show if not first page ?></td>
       <td><?php if ($pageNum_rsPieces < $totalPages_rsPieces) { // Show if not last page ?>
           <a href="<?php printf("%s?pageNum_rsPieces=%d%s", $currentPage, min($totalPages_rsPieces, $pageNum_rsPieces + 1), $queryString_rsPieces); ?>"><img src="images/Next.gif" /></a>
           <?php } // Show if not last page ?></td>
       <td><?php if ($pageNum_rsPieces < $totalPages_rsPieces) { // Show if not last page ?>
           <a href="<?php printf("%s?pageNum_rsPieces=%d%s", $currentPage, $totalPages_rsPieces, $queryString_rsPieces); ?>"><img src="images/Last.gif" /></a>
           <?php } // Show if not last page ?></td>
     </tr>
   </table>
   </div>
     <p align="center">&nbsp;</p>
   <p align="center">&nbsp;</p>
<?php if ($totalRows_rsPieces == 0) { // Show if recordset empty ?>
  <h1 align="center">VOS STOCKS SONT VIDES POUR LE MOMENT </h1>
 
  <?php } // Show if recordset empty ?>
   <p align="center">&nbsp;</p>
   
   <p align="center">&nbsp;</p>
  
</div><!---Rightcol--->
</div>
<?php include_once('../footer/footer.php'); ?>
</body>
</html>
<?php
mysql_free_result($rsPieces);
?>
