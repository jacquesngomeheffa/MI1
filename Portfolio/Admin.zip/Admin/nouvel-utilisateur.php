<?php require_once('../Connections/connexion.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "admin";
$MM_donotCheckaccess = "false";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && false) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "../Connexion.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

// Hash Password field
if (isset($_POST['motdepasse']) && $_POST['motdepasse'] <> ""){$_POST['motdepasse'] = md5($_POST['motdepasse']);}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO ficheclient (Nom, Prenom, Telephone, Entreprise, Adresse, Email) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['nom'], "text"),
                       GetSQLValueString($_POST['prenom'], "text"),
                       GetSQLValueString($_POST['telephone'], "text"),
                       GetSQLValueString($_POST['entreprise'], "text"),
                       GetSQLValueString($_POST['adresse'], "text"),
                       GetSQLValueString($_POST['email'], "text"));

  mysql_select_db($database_connexion, $connexion);
  $Result1 = mysql_query($insertSQL, $connexion) or die(mysql_error());

  $insertGoTo = "page-utilisateur.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO connecter (AdresEmail, mot_de_passe, userlevel) VALUES (%s, %s, %s)",
                       GetSQLValueString($_POST['email'], "text"),
                       GetSQLValueString($_POST['motdepasse'], "text"),
                       GetSQLValueString($_POST['userlevel'], "text"));

  mysql_select_db($database_connexion, $connexion);
  $Result1 = mysql_query($insertSQL, $connexion) or die(mysql_error());
}

mysql_select_db($database_connexion, $connexion);
$query_rsTypeUser = "SELECT * FROM `type user`";
$rsTypeUser = mysql_query($query_rsTypeUser, $connexion) or die(mysql_error());
$row_rsTypeUser = mysql_fetch_assoc($rsTypeUser);
$totalRows_rsTypeUser = mysql_num_rows($rsTypeUser);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Buc motor</title>
<link rel="shortcut icon" href="favicon.ico" />
<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'>
<link href="css/styles.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationConfirm.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationConfirm.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header-wrap">
	<div class="header">
		<div class="logo"><h1>BUC motor</h1>
		</div>
		<div class="menu">
            	<ul>
       		  <li><a href="index.php" >Acceuil</a></li>
         
          
                <li class="dropbtn dropdown"><a href="#" class="active">Gestion Administrateur</a>

                <ul class="dropdown-content">
               <a  href="Comptabilite-BUC/depensebuc.php"> Section Comptabilité</a>

                 <a href="rticle-vente.php">Gestion de stock</a>
                 <a href="page-utilisateur.php"> Mes Utilisateurs</a>

                 <a href="nouvel-utilisateur.php"> Inscrire un User</a>
                </ul>
                </li>
                                <li><a href="commande-des-clients.php">Commandes</a></li>
              <li><a href="<?php echo $logoutAction ?>">Déconnexion</a></li>
        	</ul>
        </div>
	</div>
</div><!---header-wrap--->

<div class="wrap">
	<div class="leftcol">
		<div class="search">
			<div class="title">
            	<h1>Site Search</h1>
                <div class="search-input"><input name="" type="text" class="input-style"/></div>
                <div class="search-btn"><img src="images/search-btn.jpg" alt="search" /></div>
            </div>
        </div>

		<div class="block">
        	<div class="panel">
            	<div class="title">
                	<h1 align="center">AUTRE MENU</h1>
              </div>
              <div class="content">
           	    <ul >
                <li>
                	      <div align="center" class="autremenu"><a href="Comptabilite-BUC/depensebuc.php"> Section Comptabilité</a></div>
                	    </li>
                       <li>
               	         <div align="center" class="autremenu"><a href="page-utilisateur.php"> Mes Utilisateurs</a></div>
           	      </li>
           	      <li>
                	      <div align="center" class="autremenu"><a href="about.php"> A propos de nous</a></div>
                	    </li>
                	    <li>
                	      <div align="center" class="autremenu"><a href="contact.php"> Contactez-nous </a></div>
                	    </li> 
                	    <li>
                	      <div align="center" class="autremenu"><a href="nouvel-utilisateur.php"> Inscrire un User</a></div>
                	    </li>
                	    
              	    </ul>
                </div>
        	</div>
		</div>
        
        <div class="block2">
        	<?php include_once('../Personnels/personnel.php'); ?>
                </div>
            </div>
	</div><!---leftcol--->


<div class="rightcol">
  <div class="page">
		<div class="panel mar-bottom">
			<div class="title">
  
           	  <h1>&nbsp;</h1>
           	  <h1 align="center" class="cssbutton">INSCRIVEZ UN NOUVEL USER</h1>
           	  <p>&nbsp;</p>
           	  <form id="form1" name="form1" method="POST" action="<?php echo $editFormAction; ?>">
           	    <table width="">
           	      <tr>
           	        <td height="60"><h2>Nom*:</h2></td>
           	        <td><span id="sprytextfield1">
           	          <input name="nom" type="text" class="inputtextfield" id="nom" size="25" />
       	            <span class="textfieldRequiredMsg">Une valeur est obligatoire.</span></span></td>
       	          </tr>
           	      <tr>
           	        <td height="60"><h2>Prénom*:</h2></td>
           	        <td><span id="sprytextfield2">
           	          <input name="prenom" type="text" class="inputtextfield" id="prenom" size="25" />
       	            <span class="textfieldRequiredMsg">Une valeur est obligatoire.</span></span></td>
       	          </tr>
           	      <tr>
           	        <td height="60"><h2>Numero de telephone*:</h2></td>
           	        <td><span id="sprytextfield3">
           	          <input name="telephone" type="text" class="inputtextfield" id="telephone" size="25" />
       	            <span class="textfieldRequiredMsg">Une valeur est obligatoire.</span></span></td>
       	          </tr>
           	      <tr>
           	        <td><h2>Nom Entreprise:</h2></td>
           	        <td><input name="entreprise" type="text" class="inputtextfield" id="entreprise" size="25" /></td>
       	          </tr>
           	      <tr>
           	        <td height="60"><h2>Votre adresse:</h2></td>
           	        <td><input name="adresse" type="text" class="inputtextfield" id="adresse" size="25" /></td>
       	          </tr>
           	      <tr>
           	        <td height="60"><h2>Adresse e-mail*:</h2></td>
           	        <td><span id="sprytextfield4">
                    <input name="email" type="text" class="inputtextfield" id="email" size="25" />
                    <span class="textfieldRequiredMsg">Une valeur est obligatoire.</span><span class="textfieldInvalidFormatMsg">Format non valide.</span></span></td>
       	          </tr>
           	      <tr>
           	        <td height="60"><h2>Mot de passe*:</h2></td>
           	        <td><span id="sprypassword1">
                    <input name="motdepasse" type="password" class="inputtextfield" id="motdepasse" size="25" />
                  <span class="passwordRequiredMsg">Een waarde is verplicht.</span><span class="passwordMinCharsMsg">Er zijn minder dan het minimum aantal tekens.</span></span></tr>
           	      <tr>
           	        <td height="60"><h2>Confirmer mot de passe:</h2></td>
           	        <td><span id="spryconfirm1">
           	          <input name="motdepasse2" type="password" class="inputtextfield" id="motdepasse2" size="25" />
       	            <span class="confirmRequiredMsg">Une valeur est obligatoire.</span><span class="confirmInvalidMsg">De waarden komen niet overeen.</span></span></td>
       	          </tr>
                <tr>
           	        <td><h2>Type User:</h2></td>
           	        <td><label for="userlevel"></label>
           	          <select name="userlevel" id="userlevel" >
                       <option selected="selected" value="0">--Type User--</option>
           	            <?php
do {  
?>
           	            <option value="<?php echo $row_rsTypeUser['TypeUser']?>"><?php echo $row_rsTypeUser['TypeUser']?></option>
           	            <?php
} while ($row_rsTypeUser = mysql_fetch_assoc($rsTypeUser));
  $rows = mysql_num_rows($rsTypeUser);
  if($rows > 0) {
      mysql_data_seek($rsTypeUser, 0);
	  $row_rsTypeUser = mysql_fetch_assoc($rsTypeUser);
  }
?>
                  </select></td>
       	          </tr>
       	        </table>
           	    <p>&nbsp;</p>
           	    <p align="center">
           	      <input name="Inscrivez-vous" type="submit" class="cssbutton" id="Inscrivez-vous" value="Inscrivez le user" />
           	     
           	    </p>
           	    <input type="hidden" name="MM_insert" value="form1" />
              </form>
           	  <p>&nbsp;</p>
          </div>
        </div>
        
       
	</div><!---page--->
</div><!---Rightcol--->
</div>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "email");
var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1", {validateOn:["blur"], minChars:8});
var spryconfirm1 = new Spry.Widget.ValidationConfirm("spryconfirm1", "motdepasse");
</script>
 <?php include_once('../footer/footer.php'); ?>
</body>
</html>
<?php
mysql_free_result($rsTypeUser);
?>
