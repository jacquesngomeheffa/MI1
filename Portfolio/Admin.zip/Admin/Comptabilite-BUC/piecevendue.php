<?php require_once('../../Connections/connexion.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "../../Connexion.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "admin";
$MM_donotCheckaccess = "false";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && false) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "../../Connexion.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_rsPiecevendue = 10;
$pageNum_rsPiecevendue = 0;
if (isset($_GET['pageNum_rsPiecevendue'])) {
  $pageNum_rsPiecevendue = $_GET['pageNum_rsPiecevendue'];
}
$startRow_rsPiecevendue = $pageNum_rsPiecevendue * $maxRows_rsPiecevendue;

mysql_select_db($database_connexion, $connexion);
$query_rsPiecevendue = "SELECT * FROM piecevendu";
$query_limit_rsPiecevendue = sprintf("%s LIMIT %d, %d", $query_rsPiecevendue, $startRow_rsPiecevendue, $maxRows_rsPiecevendue);
$rsPiecevendue = mysql_query($query_limit_rsPiecevendue, $connexion) or die(mysql_error());
$row_rsPiecevendue = mysql_fetch_assoc($rsPiecevendue);

if (isset($_GET['totalRows_rsPiecevendue'])) {
  $totalRows_rsPiecevendue = $_GET['totalRows_rsPiecevendue'];
} else {
  $all_rsPiecevendue = mysql_query($query_rsPiecevendue);
  $totalRows_rsPiecevendue = mysql_num_rows($all_rsPiecevendue);
}
$totalPages_rsPiecevendue = ceil($totalRows_rsPiecevendue/$maxRows_rsPiecevendue)-1;

$queryString_rsPiecevendue = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_rsPiecevendue") == false && 
        stristr($param, "totalRows_rsPiecevendue") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_rsPiecevendue = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_rsPiecevendue = sprintf("&totalRows_rsPiecevendue=%d%s", $totalRows_rsPiecevendue, $queryString_rsPiecevendue);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Buc motor</title>
<link rel="shortcut icon" href="favicon.ico" />
<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'>
<link href="css/styles.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="clearing"></div>
<div class="header-wrap">
  <div class="header">
		<div class="logo"><h1>Comptabilité en ligne</h1>
		</div>
        <div class="clearing"></div>
	  <div class="menu">
        	<ul>
       		  <li><a href="../index.php" class="active">Acceuil</a></li>
         <li><a href="depensebuc.php">Depense de BUC</a></li>
                
                <li><a href="Reparation.php">Liste de reparation</a></li>
                                <li><a href="piecevendue.php">Pièce vendue</a></li>
              <li><a href="ajouter-une-reparation.php"> Ajouter une reparation</a>
              <li><a href="ajouterDepensebuc.php" class="autremenu">Ajouter une depense Buc</a></li></li>
               <li><a href="<?php echo $logoutAction ?>">Déconnectez-vous</a></li>
        	</ul>
        </div>
	</div>
</div><!---header-wrap--->
 <div class="clearing"></div>
<div class="wrap"><!---page--->
<div class="autremenu"><!---page--->
<div>
  <h1 align="center" class="cssbutton">APERÇU DES PIÈCES VENDUE</h1>
  <p>&nbsp;</p>
  
  <form id="form1" name="form1" method="post" action="">
  <div align="center">
    <?php if ($totalRows_rsPiecevendue > 0) { // Show if recordset not empty ?>
      <table width="">
        <tr>
          <td width="250" height="60"><h2 align="center">Nom de la pièce</h2></td>
          <td width="250" height="60"><h2 align="center">Quantité</h2></td>
          <td width="250" height="60"><h2 align="center">Prix par piece</h2></td>
          <td width="250" height="60"><h2 align="center">Date</h2></td>
        </tr>
        <?php $date2 = date("d-m-y", strtotime($row_rsPiecevendue['Date']));
		 
		  $quantite = 0 ; 
		 
		 $prixDeux = 0
		   ?>

        <?php do { ?>
       <?php  $date1= date("d-m-y", strtotime($row_rsPiecevendue['Date']));?>

        
             
       <?php if ($date1 == $date2 ){?>
                  <?php 
	   $quantite = $quantite + $row_rsPiecevendue['quantite'];
	   $calculQuantite = $row_rsPiecevendue['quantite'];
	   $prixBase=  $row_rsPiecevendue['PrixParPiece'];
	   
	   ?>
           <?php 
		  
		   $resultat  =  ( ($prixBase) * ($calculQuantite));
	   $prix = $prix +  $resultat ;?>
       
          <tr>
            <td width="250" height="30"><div align="center"><?php echo $row_rsPiecevendue['piece']; ?></div></td>
            <td width="250" height="30"><div align="center"><?php echo $row_rsPiecevendue['quantite']; ?></div></td>
            <td width="250" height="30"><div align="center"><?php echo $row_rsPiecevendue['PrixParPiece']; ?></div></td>
            <td width="250" height="30"><div align="center"><?php echo date("d-m-y",strtotime($row_rsPiecevendue['Date'])); ?></div></td>
         </tr>
          <?php }else {?>

                <tr>
            <td width="250" height="10"><div align="center"> </div>
</td>
            <td width="250" height="10"><div align="center">-------</div></td>
            <td width="250" height="10"><div align="center">-------</div></td>
            <td width="250" height="10"><div align="center"></div></td>
            </tr>
          
           <tr class="total">
            <td width="250" height="50"><div align="center"> Total <?php echo $date2 ?></div></td>
            <td width="250" height="50"><div align="center"><?php echo $quantite ?></div></td>
            <td width="250" height="50"><div align="center"><?php echo $prix ?></div> </td>
            <td width="250" height="50"><div align="center"></div></td>
            </tr>
            <?php $quantite = $row_rsPiecevendue['quantite'] ;
			 $resultat  =  ( ($row_rsPiecevendue['PrixParPiece']) * ($quantite));
			$prix = $resultat
			?>
                   <tr>
            <td width="250" height="30"><div align="center"><?php echo $row_rsPiecevendue['piece']; ?></div></td>
            <td width="250" height="30"><div align="center"><?php echo $row_rsPiecevendue['quantite']; ?></div></td>
            <td width="250" height="30"><div align="center"><?php echo $row_rsPiecevendue['PrixParPiece']; ?></div></td>
            <td width="250" height="30"><div align="center"><?php echo date("d-m-y",strtotime($row_rsPiecevendue['Date'])); ?></div></td>
         </tr>
          <?php }?>
      
                             <?php 

	   ?>
          <?php  $date2 = $date1 ?>
          <?php } while ($row_rsPiecevendue = mysql_fetch_assoc($rsPiecevendue)); ?>
           <tr>
            <td width="250" height="10"><div align="center"></div>
</td>
            <td width="250" height="10"><div align="center">-------</div></td>
            <td width="250" height="10"><div align="center">-------</div></td>
            <td width="250" height="10"><div align="center"></div></td>
            </tr>
          
           <tr class="total">
            <td width="250" height="30"><div align="center">Total <?php echo $date2 ?></div></td>
            <td width="250" height="30"><div align="center"><?php echo $quantite ?></div></td>
            <td width="250" height="30"><div align="center"><?php echo $prix ?></div> </td>
            <td width="250" height="30"><div align="center"></div></td>
            </tr>
      </table>
      <?php } // Show if recordset not empty ?>
  </div>
  </form>
  <div align="center"></div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <?php if ($totalRows_rsPiecevendue == 0) { // Show if recordset empty ?>
  <h1 align="center">Pas de pièce vendue </h1>
  <?php } // Show if recordset empty ?>
<p>&nbsp;</p>
  <p>&nbsp;</p>
  <div align="center">
  <table border="0">
    <tr>
      <td width="50" height="30"><?php if ($pageNum_rsPiecevendue > 0) { // Show if not first page ?>
          <a href="<?php printf("%s?pageNum_rsPiecevendue=%d%s", $currentPage, 0, $queryString_rsPiecevendue); ?>"><img src="images/First.gif" /></a>
          <?php } // Show if not first page ?></td>
      <td width="50" height="30"><?php if ($pageNum_rsPiecevendue > 0) { // Show if not first page ?>
          <a href="<?php printf("%s?pageNum_rsPiecevendue=%d%s", $currentPage, max(0, $pageNum_rsPiecevendue - 1), $queryString_rsPiecevendue); ?>"><img src="images/Previous.gif" /></a>
          <?php } // Show if not first page ?></td>
      <td width="50" height="30"><?php if ($pageNum_rsPiecevendue < $totalPages_rsPiecevendue) { // Show if not last page ?>
          <a href="<?php printf("%s?pageNum_rsPiecevendue=%d%s", $currentPage, min($totalPages_rsPiecevendue, $pageNum_rsPiecevendue + 1), $queryString_rsPiecevendue); ?>"><img src="images/Next.gif" /></a>
          <?php } // Show if not last page ?></td>
      <td width="50" height="30"><?php if ($pageNum_rsPiecevendue < $totalPages_rsPiecevendue) { // Show if not last page ?>
          <a href="<?php printf("%s?pageNum_rsPiecevendue=%d%s", $currentPage, $totalPages_rsPiecevendue, $queryString_rsPiecevendue); ?>"><img src="images/Last.gif" /></a>
          <?php } // Show if not last page ?></td>
    </tr>
  </table>
    <p>&nbsp;</p>
  </div>
<form id="form2" name="form2" method="post" action="ajouter-une-piece-vendue.php">
  <div align="center">
      <input name="ajouter" type="submit" class="cssbutton" id="ajouter" value="Ajouter une nouvelle pièce vendue" />
    </div>
</form>
  <p>&nbsp;</p>
</div>


</div>
</div>
 <div class="clearing"></div>

<?php include_once('footer/footer.php'); ?>
</body>
</html>
<?php
mysql_free_result($rsPiecevendue);
?>
