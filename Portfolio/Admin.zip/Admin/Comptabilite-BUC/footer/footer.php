<link href="css/styles.css" rel="stylesheet" type="text/css" />
<div class="footer-wrap">
	<div class="footer">
		<div class="bolg">
            <div class="title">
            	<h1>Buc Motor Cameroun</h1>
            </div>
        	<div class="panel mar-right115">
            <div class="content">
            	<ul>
                	<li><img src="images/icon1.png" alt="icon" /></li>
                    <li>Buc motor<br />
                  Août 2016</li>
            	</ul>
                <p>Buc est une entreprise basée sur la vente et la reparation des motos, tout pour vous faciliter la tâche et rouler confortablement sans vous soucier de quelque chose.</p>
                <p><a href="#">Plus d'info + </a></p>
            </div>
           </div> 
           
           <div class="panel">
            <div class="content">
            	<ul>
                	<li><img src="images/icon1.png" alt="icon" /></li>
                    <li>Buc motor<br />
Août 2016</li>
            	</ul>
                <p>Nous vous aidons dans le but de pouvoir faciliter vos commandes en ligne tout comme sur place, reserver vos pièces en ligne et bien d'autre chose.</p>
                <p><a href="#">Plus d'info + </a></p>
            </div>
           </div>
        </div>
        
        <div class="quickcontact">
        	<div class="title">
            	<h1> Contact Rapide</h1>
            </div>
			<div class="panel">
            <div class="content">
              <p>Buc Motor: tout pres de 
                Bepanda, Douala, Camaroun</p>
                <p><span>Tel: :</span> +237 888 88888</p>
                <p><span>Email :</span> buc2016@gmail.com</p>
            </div>
           </div>
        </div>
    </div>
</div><!---footer--->
<div class="copyright-wrap">
	<div class="copyright">
    	<div class="content">
        	<p>© 2012 All Rights Reserved  |  Privacy Policy   
            Designed by :<a href="www.Bucmotor.cm." class="active"> www.Bucmotor.cm.</a>   
             Images From:<a href=" www.photorack.net"> www.photorack.net</a></p>
        </div>
    </div>
</div><!---copyright-wrap--->