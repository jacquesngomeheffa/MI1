<?php require_once('../Connections/connexion.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "../index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form3")) {
  $updateSQL = sprintf("UPDATE commandeclient SET IDclient=%s, Reference=%s, Nompiece=%s, Quantite=%s, Facture=%s WHERE DateDeReservation=%s",
                       GetSQLValueString($_POST['IDclient'], "int"),
                       GetSQLValueString($_POST['Reference'], "text"),
                       GetSQLValueString($_POST['Nompiece'], "text"),
                       GetSQLValueString($_POST['Quantite'], "int"),
                       GetSQLValueString($_POST['Facture'], "text"),
                       GetSQLValueString($_POST['DateDeReservation'], "date"));

  mysql_select_db($database_connexion, $connexion);
  $Result1 = mysql_query($updateSQL, $connexion) or die(mysql_error());

  $updateGoTo = "commande-des-clients.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_rsComande = "-1";
if (isset($_GET['DateDeReservation'])) {
  $colname_rsComande = $_GET['DateDeReservation'];
}
mysql_select_db($database_connexion, $connexion);
$query_rsComande = sprintf("SELECT * FROM commandeclient WHERE DateDeReservation = %s", GetSQLValueString($colname_rsComande, "date"));
$rsComande = mysql_query($query_rsComande, $connexion) or die(mysql_error());
$row_rsComande = mysql_fetch_assoc($rsComande);
$totalRows_rsComande = mysql_num_rows($rsComande);

mysql_select_db($database_connexion, $connexion);
$query_rsTypeFacture = "SELECT * FROM facture";
$rsTypeFacture = mysql_query($query_rsTypeFacture, $connexion) or die(mysql_error());
$row_rsTypeFacture = mysql_fetch_assoc($rsTypeFacture);
$totalRows_rsTypeFacture = mysql_num_rows($rsTypeFacture);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Buc motor</title>
<link rel="shortcut icon" href="favicon.ico" />
<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'>
<link href="css/styles.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header-wrap">
	<div class="header">
		<div class="logo"><h1>BUC motor</h1>
		</div>
		<div class="menu">
            	<ul>
       		  <li><a href="index.php" >Acceuil</a></li>
         
          
                <li class="dropbtn dropdown"><a href="#">Gestion Administrateur</a>

                <ul class="dropdown-content">
               <a  href="Comptabilite-BUC/depensebuc.php"> Section Comptabilité</a>

                 <a href="articles-de-ventes.php">Gestion de stock</a>
                 <a href="page-utilisateur.php"> Mes Utilisateurs</a>

                 <a href="nouvel-utilisateur.php"> Inscrire un User</a>
                </ul>
                </li>
                                <li><a href="commande-des-clients.php" class ="active">Commandes</a></li>
              <li><a href="<?php echo $logoutAction ?>">Déconnexion</a></li>
        	</ul>
        </div>
	</div>
</div><!---header-wrap--->

<div class="wrap">
	<div class="leftcol">
		<div class="search">
			<div class="title">
            	<h1>Site Search</h1>
                <div class="search-input"><input name="" type="text" class="input-style"/></div>
                <div class="search-btn"><img src="images/search-btn.jpg" alt="search" /></div>
            </div>
        </div>

		<div class="block">
        	<div class="panel">
            	<div class="title">
           <h1 align="center">AUTRE MENU</h1>
              </div>
              <div class="content">
                	    <ul >
                <li>
                	      <div align="center" class="autremenu"><a href="Comptabilite-BUC/depensebuc.php"> Section Comptabilité</a></div>
                	    </li>
                       <li>
               	         <div align="center" class="autremenu"><a href="page-utilisateur.php"> Mes Utilisateurs</a></div>
           	      </li>
           	      <li>
                	      <div align="center" class="autremenu"><a href="about.php"> A propos de nous</a></div>
                	    </li>
                	    <li>
                	      <div align="center" class="autremenu"><a href="contact.php"> Contactez-nous </a></div>
                	    </li> 
                	    <li>
                	      <div align="center" class="autremenu"><a href="nouvel-utilisateur.php"> Inscrire un User</a></div>
                	    </li>
                	    
              	    </ul>
              </div>
        	</div>
		</div>
        
        <div class="block2">
        	<?php include_once('../Personnels/personnel.php'); ?>
                </div>
      </div>
	</div><!---leftcol--->


<div class="rightcol">
	<div class="page-content">
		<div class="panel mar-bottom">
			<div class="title">
            	<h1 align="center" class="cssbutton">MODIFIER UN COMMANDE</h1>
            </div>
            <div class="content">
            	<form action="<?php echo $editFormAction; ?>" method="post" name="form3" id="form3">
            	  <table width="">
            	    <tr>
            	      <td height="60"><h2>Nr Client</h2></td>
            	      <td><input name="IDclient" type="text" class="inputtextfield" id="IDclient" value="<?php echo $row_rsComande['IDclient']; ?>" size="25" readonly="readonly" /></td>
          	      </tr>
            	    <tr>
            	      <td height="60"><h2>Reference</h2></td>
            	      <td><input name="Reference" type="text" class="inputtextfield" id="Reference" value="<?php echo htmlentities($row_rsComande['Reference'], ENT_COMPAT, 'utf-8'); ?>" size="25" readonly="readonly" /></td>
          	      </tr>
            	    <tr>
            	      <td height="60"><h2>Nom de la pièce</h2></td>
            	      <td><input name="Nompiece" type="text" class="inputtextfield" id="Nompiece" value="<?php echo htmlentities($row_rsComande['Nompiece'], ENT_COMPAT, 'utf-8'); ?>" size="25" readonly="readonly" /></td>
          	      </tr>
            	    <tr>
            	      <td height="60"><h2>Quantité</h2></td>
            	      <td><input name="Quantite" type="text" class="inputtextfield" id="Quantite" value="<?php echo htmlentities($row_rsComande['Quantite'], ENT_COMPAT, 'utf-8'); ?>" size="25" readonly="readonly" /></td>
          	      </tr>
            	    <tr>
            	      <td height="60"><h2>Date de la commande</h2></td>
            	      <td><input name="DateDeReservation" type="text" class="inputtextfield" id="DateDeReservation" value="<?php echo htmlentities($row_rsComande['DateDeReservation'], ENT_COMPAT, 'utf-8'); ?>" size="25" readonly="readonly" /></td>
          	      </tr>
            	    <tr>
            	      <td height="60"><h2>Etat de la Facture</h2></td>
            	      <td><label for="Facture"></label>
            	        <select name="Facture" id="Facture">
                        <option selected="selected" value="<?php echo htmlentities($row_rsComande['Facture'], ENT_COMPAT, 'utf-8'); ?>"><?php echo $row_rsComande['Facture'] ?></option>
            	          <?php
do {  
?>
            	          <option value="<?php echo htmlentities($row_rsTypeFacture['TypeFacture'], ENT_COMPAT, 'utf-8');?>"><?php echo $row_rsTypeFacture['TypeFacture']?></option>
            	          <?php
} while ($row_rsTypeFacture = mysql_fetch_assoc($rsTypeFacture));
  $rows = mysql_num_rows($rsTypeFacture);
  if($rows > 0) {
      mysql_data_seek($rsTypeFacture, 0);
	  $row_rsTypeFacture = mysql_fetch_assoc($rsTypeFacture);
  }
?>
                      </select></td>
          	      </tr>
          	    </table>
            	  
            	  <p>&nbsp;</p>
            	  <p align="center">
            	    <input name="Envoyer" type="submit" class="cssbutton" id="Envoyer" value="METTRE À JOUR " />
            	  </p>                  <input type="hidden" name="MM_update" value="form3" />
              </form>

               
                <p>&nbsp;</p>
<p>&nbsp;</p>
</div>
        </div>
        <div class="clearing"></div>
	</div><!---page--->
</div><!---Rightcol--->
</div>
<?php include_once('../footer/footer.php'); ?>
</body>
</html>
<?php
mysql_free_result($rsComande);

mysql_free_result($rsTypeFacture);

mysql_free_result($rsComande);
?>
