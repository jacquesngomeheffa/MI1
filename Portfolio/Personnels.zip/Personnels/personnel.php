<link href="../css/styles.css" rel="stylesheet" type="text/css" />
        	<div class="title">
        	 <h1 align="center">LE PERSONNELS</h1></div>
            	<div class="panel">
                    <img src="images/image1.png" alt="image" />
                    <div class="content">
                    <p>David Urbain </p>
                   	  <p>PDG, Manager </p>
                        <div class="button"><a href="#">More</a></div>
                    </div>
                </div>
                <div class="panel">
                    <img src="images/image2.png" alt="image" />
                    <div class="content">
                    <p>Biatho Rebecca </p>
                   	  <p>Support Manager</p>
                        <div class="button"><a href="#">More</a></div>
                    </div>
                </div>
                <div class="panel">
                    <img src="images/image3.png" alt="image" />
                    <div class="content">
                    <p>Ntonga Alain </p>
                   	  <p>Gérant-Mécanicien</p>
                        <div class="button"><a href="#">More</a></div>
                    </div>
            </div>
                      
                     <div class="panel bor-bottm-non">
                    <img src="images/ose.png" alt="image" />
                    <div class="content">
                    <p>Dikein long Osé </p>
                   	  <p>Comptable</p>
                        <div class="button"><a href="#">More</a></div>
            </div>