<link href="css/styles.css" rel="stylesheet" type="text/css" />
<div class="footer-wrap">
	<div class="footer">
		<div class="bolg">
            <div class="title">
            	<h1>Buc Motor Cameroun</h1>
            </div>
        	<div class="panel mar-right115">
            <div class="content">
            	<ul>
                	<li><img src="images/icon1.png" alt="icon" /></li>
                    <li>Buc motor<br />
                  Août 2016</li>
            	</ul>
                <p>Buc est une entreprise basée sur la vente et la reparation des motos, tout pour vous faciliter la tâche et rouler confortablement sans vous soucier de quelque chose.</p>
                <p><a href="#">Plus d'info + </a></p>
            </div>
           </div> 
           
           <div class="panel">
            <div class="content">
            	<ul>
                	<li><img src="images/icon1.png" alt="icon" /></li>
                    <li>Buc motor<br />
Août 2016</li>
            	</ul>
                <p>Nous vous aidons dans le but de pouvoir faciliter vos commandes en ligne tout comme sur place, reserver vos pièces en ligne et bien d'autre chose.</p>
                <p><a href="#">Plus d'info + </a></p>
            </div>
           </div>
        </div>
        
        <div class="snelContact">
        	<div class="title">
            	<h1> Contact Rapide</h1>
            </div>
			<div class="panel">
            <div class="content">
              <p>Buc Motor: tout pres de 
                Bepanda, Douala, Camaroun</p>
                <p><span>Tel: :</span> (+237) 670 009 747 /  696 173 629</p>
                <p><span>Email :</span> bucmotor16@yahoo.fr</p>
            </div>
           </div>
        </div>
    </div>
</div><!---footer--->
<div class="copyright-algemeneContainer">
	<div class="copyright">
    	<div class="content">
        	<p>© 2012 All Rights Reserved  |  Privacy Policy   
            Designed by :<a href="http://www.Bucmotor.com" class="active"> www.Bucmotor.com.</a>   
             Images From:<a href="http://www.bucmotor.com/images"> www.bucmotor.com/images</a></p>
        </div>
    </div>
</div><!---copyright-algemeneContainer--->