<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "../Connexion.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8" >
<title>Buc motor</title>
<link rel="shortcut icon" href="favicon.ico" />
<meta name="viewport" content="width=device-width, height=device-height" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header-algemeneContainer">
	<div class="header">
		<div class="logo"><h1>BUC motor</h1>
		</div>
		<div class="menu">
        	<ul>
        		<li><a href="index.php" class="active">Acceuil</a></li>
           
                <li><a href="Article vente.php">Articles ventes          </a></li>
                
                
<li><a href="Mescommandes.php">Mes commandes </a></li>
              <li><a href="<?php echo $logoutAction ?>">Déconnectez-vous</a></li>
        	</ul>
        </div>
	</div>
</div><!---header-algemeneContainer--->

<div class="algemeneContainer">
  <div class="leftcol">
    <div class="search">
      <div class="title">
        <h1>Site Search</h1>
        <div class="search-input">
          <input name="" type="text" class="input-style"/>
        </div>
        <div class="search-btn"><img src="images/search-btn.jpg" alt="search" /></div>
      </div>
    </div>
    <div class="block">
      <div class="panel">
        <div class="title">
          <h1 align="center">AUTRE MENU</h1>
        </div>
        <div class="content">
          <ul >
            <li>
              <div align="center"><a href="Commandes.php" class="autremenu">Commander en ligne </a></div>
            </li>
            <li>
              <div align="center" class="autremenu"><a href="about.php"> A propos de nous</a></div>
            </li>
            <li>
              <div align="center" class="autremenu"><a href="contact.php"> Contactez-nous </a></div>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="block2">
      <?php include_once('../Personnels/personnel.php'); ?>
      </div>
    </div>
  </div>
  <!---leftcol--->
  
  
  <div class="rightcol">
    <div class="page-content">
      <div class="panel mar-bottom">
        <div class="title">
          <h1 align="center">A Propos de nous</h1>
          <p align="center">&nbsp;</p>
          <h3>BUC motor est une entreprise de vente des pièces de motos détachées et en gros, et vous fournit aussi ses services en réparation.Si dessous vous trouverez un aperçu de nos different menbre du personnel.</h3>
        </div>
        <div class="content">
          <div class="box mar-Right">
            <div class="panel">
              <img src="images/image4.jpg" alt="image" width="220" height="260" />
              <div class="title">
                <h1>Web designer</h1>
                </div>
              <div class="content">
                <p>Gère le site web de l'ntreprise</p>
                <div class="button"><a href="#">More Info</a></div>
                </div>
            </div>
          </div>
          <div class="box">
            <div class="panel">
              <img src="images/image5.jpg" alt="image" width="220" height="260" />
              <div class="title">
                <h1>Employé polyvalent</h1>
                </div>
              <div class="content">
                <p>touche un peu à tout dans l'entrprise</p>
                <div class="button"><a href="#">More Info</a></div>
                </div>
            </div>
          </div>
          <div class="clearing"></div>
          <div class="panel mar-top">
            
          </div>
          <img src="images/image6.jpg" alt="image" width="220" height="260" />
          <div class="content">
            <div class="title">
            <h1>Comptable</h1></div>
            
            <div class="content">
              <p>Gère la comptabilité de l'entreprise</p>
              <div class="button2"><a href="#">More Info</a></div>
            </div>
          </div>
          </div>
        </div>
      <div class="clearing"></div>
      </div><!---page--->
  </div><!---Rightcol--->
</div>
<?php include_once('footer/footer.php'); ?>
</html>
