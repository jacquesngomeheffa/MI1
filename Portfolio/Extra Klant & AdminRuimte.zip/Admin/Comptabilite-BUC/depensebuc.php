<?php require_once('../../Connections/connexion.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "../../Connexion.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "admin";
$MM_donotCheckaccess = "false";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && false) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "../../Connexion.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_rsDepenseBuc = 10;
$pageNum_rsDepenseBuc = 0;
if (isset($_GET['pageNum_rsDepenseBuc'])) {
  $pageNum_rsDepenseBuc = $_GET['pageNum_rsDepenseBuc'];
}
$startRow_rsDepenseBuc = $pageNum_rsDepenseBuc * $maxRows_rsDepenseBuc;

mysql_select_db($database_connexion, $connexion);
$query_rsDepenseBuc = "SELECT * FROM depensebuc";
$query_limit_rsDepenseBuc = sprintf("%s LIMIT %d, %d", $query_rsDepenseBuc, $startRow_rsDepenseBuc, $maxRows_rsDepenseBuc);
$rsDepenseBuc = mysql_query($query_limit_rsDepenseBuc, $connexion) or die(mysql_error());
$row_rsDepenseBuc = mysql_fetch_assoc($rsDepenseBuc);

if (isset($_GET['totalRows_rsDepenseBuc'])) {
  $totalRows_rsDepenseBuc = $_GET['totalRows_rsDepenseBuc'];
} else {
  $all_rsDepenseBuc = mysql_query($query_rsDepenseBuc);
  $totalRows_rsDepenseBuc = mysql_num_rows($all_rsDepenseBuc);
}
$totalPages_rsDepenseBuc = ceil($totalRows_rsDepenseBuc/$maxRows_rsDepenseBuc)-1;

$queryString_rsDepenseBuc = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_rsDepenseBuc") == false && 
        stristr($param, "totalRows_rsDepenseBuc") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_rsDepenseBuc = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_rsDepenseBuc = sprintf("&totalRows_rsDepenseBuc=%d%s", $totalRows_rsDepenseBuc, $queryString_rsDepenseBuc);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8" >
<title>Buc motor</title>
<link rel="shortcut icon" href="favicon.ico" />
<meta name="viewport" content="width=device-width, height=device-height" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="clearing"></div>
<div class="header-algemeneContainer">
  <div class="header">
		<div class="logo">
		  <h1>Comptabilité en ligne</h1>
		</div>
        <div class="clearing"></div>
	  <div class="menu">
        	<ul>
       		  <li><a href="../index.php" class="active">Acceuil</a></li>
         <li><a href="depensebuc.php">Depense de BUC</a></li>
                
                <li><a href="Reparation.php">Liste de reparation</a></li>
                                <li><a href="piecevendue.php">Pièce vendue</a></li>
              <li><a href="ajouter-une-reparation.php"> Ajouter une reparation</a>
              <li><a href="ajouterDepensebuc.php" class="autremenu">Ajouter une depense Buc</a></li></li>
               <li><a href="<?php echo $logoutAction ?>">Déconnectez-vous</a></li>
        	</ul>
        </div>
	</div>
</div><!---header-algemeneContainer--->
 <div class="clearing"></div>
<div class="algemeneContainer"><!---page--->
<div class="autremenu"><!---page--->
<div> 
  <h1 align="center" class="cssbutton">DEPENSE DE BUC</h1>
  <p align="center">&nbsp;</p>
  <form id="form1" name="form1" method="post" action="">
    <?php if ($totalRows_rsDepenseBuc > 0) { // Show if recordset not empty ?>
     <div align="center">
  <table width="">
    <tr>
      <td width="250" height="60"><h2 align="center">Les impots</h2></td>
      <td width="250" height="60"><h2 align="center">Electricité</h2></td>
      <td width="250" height="60"><h2 align="center">Le Loyer</h2></td>
      <td width="250" height="60"><h2 align="center">Internet</h2></td>
      <td width="150" height="60"><h2 align="center">Date</h2></td>
      <td width="400" height="60"><h2 align="center">Divers</h2></td>
      <td width="150" height="60"><h2 align="center">&nbsp;</h2></td>
      </tr>
    <?php do { ?>
      <tr>
        <td width="250" height="50"><div align="center"><?php echo $row_rsDepenseBuc['impot']; ?></div></td>
        <td width="250" height="50"><div align="center"><?php echo $row_rsDepenseBuc['electricite']; ?></div></td>
        <td width="250" height="30"><div align="center"><?php echo $row_rsDepenseBuc['loyer']; ?></div></td>
        <td width="250" height="50"><div align="center"><?php echo $row_rsDepenseBuc['internet']; ?></div></td>
        <td width="150" height="50"><div align="center"><?php echo date("d-m-y",strtotime($row_rsDepenseBuc['Date'])); ?></div></td>
        
        <td width="400" height="50"><div align="center"><?php echo $row_rsDepenseBuc['fraissupplementaire']; ?></div></td>
        <td width="150" height="50"><div align="center"><a href="Afficher-Facture.php?IDdepensebuc=<?php echo $row_rsDepenseBuc['IDdepensebuc']; ?>">Afficher</a></div></td>
      </tr>
      <?php } while ($row_rsDepenseBuc = mysql_fetch_assoc($rsDepenseBuc)); ?>
  </table>
  </div>
    <p>&nbsp;</p>
   <p>&nbsp;</p>
    <div align="center">
    <table border="0">
      <tr>
        <td width="50" height="30"><?php if ($pageNum_rsDepenseBuc > 0) { // Show if not first page ?>
            <a href="<?php printf("%s?pageNum_rsDepenseBuc=%d%s", $currentPage, 0, $queryString_rsDepenseBuc); ?>"><img src="images/First.gif" /></a>
            <?php } // Show if not first page ?></td>
        <td width="50" height="30"><?php if ($pageNum_rsDepenseBuc > 0) { // Show if not first page ?>
            <a href="<?php printf("%s?pageNum_rsDepenseBuc=%d%s", $currentPage, max(0, $pageNum_rsDepenseBuc - 1), $queryString_rsDepenseBuc); ?>"><img src="images/Previous.gif" /></a>
            <?php } // Show if not first page ?></td>
        <td width="50" height="30"><?php if ($pageNum_rsDepenseBuc < $totalPages_rsDepenseBuc) { // Show if not last page ?>
            <a href="<?php printf("%s?pageNum_rsDepenseBuc=%d%s", $currentPage, min($totalPages_rsDepenseBuc, $pageNum_rsDepenseBuc + 1), $queryString_rsDepenseBuc); ?>"><img src="images/Next.gif" /></a>
            <?php } // Show if not last page ?></td>
        <td width="50" height="30"><?php if ($pageNum_rsDepenseBuc < $totalPages_rsDepenseBuc) { // Show if not last page ?>
            <a href="<?php printf("%s?pageNum_rsDepenseBuc=%d%s", $currentPage, $totalPages_rsDepenseBuc, $queryString_rsDepenseBuc); ?>"><img src="images/Last.gif" /></a>
            <?php } // Show if not last page ?></td>
      </tr>
    </table>
    </div>
<?php } // Show if recordset not empty ?>
  <?php if ($totalRows_rsDepenseBuc == 0) { // Show if recordset empty ?>
 
    <h1 align="center">PAS DE DÉPENSE BUC SAUVEGARDÉE</h1>
    <?php } // Show if recordset empty ?>
  </form>
  <p align="center">&nbsp;</p>
</div>


</div>
</div>
 <div class="clearing"></div>

<?php include_once('footer/footer.php'); ?>
</body>
</html>
<?php
mysql_free_result($rsDepenseBuc);
?>
