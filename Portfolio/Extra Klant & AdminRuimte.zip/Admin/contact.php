<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "../index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8" >
<title>Buc motor</title>
<link rel="shortcut icon" href="favicon.ico" />
<meta name="viewport" content="width=device-width, height=device-height" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header-algemeneContainer">
	<div class="header">
		<div class="logo"><h1>BUC motor</h1>
		</div>
		<div class="menu">
      	<ul>
       		  <li><a href="index.php" class="active">Acceuil</a></li>
         <li><a href="articles-de-ventes.php">Gestion de stock</a></li>
                
                <li><a href="ajouter-un-stock.php">Nouveau stock</a></li>
                                <li><a href="commande-des-clients.php">Commandes</a></li>
               <li><a href="<?php echo $logoutAction ?>">Déconnectez-vous</a></li>
        	</ul>
        </div>
	</div>
</div><!---header-algemeneContainer--->

<div class="algemeneContainer">
	<div class="leftcol">
		<div class="search">
			<div class="title">
            	<h1>Site Search</h1>
                <div class="search-input"><input name="" type="text" class="input-style"/></div>
                <div class="search-btn"><img src="images/search-btn.jpg" alt="search" /></div>
            </div>
        </div>

		<div class="block">
        	<div class="panel">
            	<div class="title">
       <h1 align="center">AUTRE MENU</h1>
              </div>
              <div class="content">
                	   <ul >
                <li>
                	      <div align="center" class="autremenu"><a href="Comptabilite-BUC/depensebuc.php"> Section Comptabilité</a></div>
                	    </li>
                       <li>
               	         <div align="center" class="autremenu"><a href="page-utilisateur.php"> Mes Utilisateurs</a></div>
           	      </li>
           	      <li>
                	      <div align="center" class="autremenu"><a href="about.php"> A propos de nous</a></div>
                	    </li>
                	    <li>
                	      <div align="center" class="autremenu"><a href="contact.php"> Contactez-nous </a></div>
                	    </li> 
                	    <li>
                	      <div align="center" class="autremenu"><a href="nouvel-utilisateur.php"> Inscrire un User</a></div>
                	    </li>
                	    
              	    </ul>
                </div>
        	</div>
		</div>
        
        <div class="block2">
        	<?php include_once('../Personnels/personnel.php'); ?>
                </div>
            </div>
	</div><!---leftcol--->


<div class="rightcol">
	<div class="page-content">
		<div class="panel mar-bottom">
			<div class="title">
            	<h1 align="center" class="cssbutton">CONTACT</h1>
        		<h2>&nbsp;</h2>
			</div>
		  <div class="panel">
      <div class="content">
        <form id="form1" name="form1" method="POST" action="sendemail.php">
          <div class="contact-form mar-top30">
            <label> <span>Nom complet</span>
              <input type="text" class="input_text" name="name" id="name"/>
            </label>
            <label> <span>Email</span>
            <input type="text" class="input_text" name="email" id="email"/>
            </label>
            <label> <span>Suject</span>
              <input type="text" class="input_text" name="subject" id="subject"/>
            </label>
            <label> <span>Message</span>
            <textarea class="message" name="message" id="message"></textarea>
            <input type="submit" class="button" name="submit" id="submit" value="Envoyer" />
            </label>
          </div>
        </form>
        <div class="address">
          <div class="panel">
            <div class="title">
              <h1>Adresse  - 01</h1>
            </div>
            <div class="content">
              <p>Buc Motor: tout pres de 
                Bepanda, Douala, Camaroun</p>
              <p><span>Telephone :</span> +237  670 009 747</p>
              <p><span>Email :</span> <a href="mailto:buc2016@gmail.com">bucmotor16@yahoo.fr</a></p>
            </div>
          </div>
        </div>
        <div class="address">
        	<div class="panel marginTop">
            <div class="title">
              <h1>Adresse  - 02</h1>
            </div>
            <div class="content">
              <p>Buc Motor: tout pres de 
                Bepanda, Douala, Camaroun</p>
              <p><span>Telephone :</span> +237 696 173 629</p>
              <p><span>Email :</span><a href="mailto:buc2016@gmail.com">bucmotor16@gmail.com</a></p>
            </div>
          </div>
         </div>
    </div>
    </div>   
            
            
            
            
            
        </div>
        <div class="clearing"></div>
	</div><!---page--->
</div><!---Rightcol--->
</div>
<?php include_once('../footer/footer.php'); ?>
</body>
</html>
